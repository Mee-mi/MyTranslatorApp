package api.application.maryam.translater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Database;
import androidx.room.Room;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.JsonArray;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navi;
    ProgressBar bar;
    TextView outputText, lang1, lang2, outputHeading;
    RelativeLayout layout;
    EditText inputText;
    ImageButton mic, camera, result, cancel, swap;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String resulttext, lang1code, lang2code, Inputlang, tranLang;
    String inputword, spokenText;
    LanguageModel languageModel = new LanguageModel();
    AppDatabase TdDatabase;
    private static final int SPEECH_REQUEST_CODE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = findViewById(R.id.parentRelative);
        lang1 = findViewById(R.id.lang1);
        outputHeading = findViewById(R.id.outputheading);
        lang2 = findViewById(R.id.lang2);
        inputText = findViewById(R.id.inputText1);
        outputText = findViewById(R.id.output);
        layout = findViewById(R.id.parentRelative);
        initiaizePreference();
        editLanguages();
        getShared();
        bar = findViewById(R.id.bar);
        bar.setVisibility(View.INVISIBLE);
        swap = findViewById(R.id.swap);

        mic = findViewById(R.id.mic);
        camera = findViewById(R.id.camera);
        result = findViewById(R.id.result);
        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.draw);
        navi = findViewById(R.id.nav);
        outputText.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.cancel);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);   //for home
        toolbar.setNavigationIcon(R.drawable.ic_baseline_menu_24);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        lang1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LanguageActivity.class);
                intent.putExtra("language", "From");
                startActivityForResult(intent, 2);


            }
        });

        navi.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.History) {
                    Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                    startActivity(intent);
                } else if (menuItem.getItemId() == R.id.Settings) {
                    Intent intent = new Intent(MainActivity.this, ConversActivity.class);
                    startActivity(intent);
                }
                drawerLayout.closeDrawers();
                return true;
            }
        });
        layout.setVisibility(View.INVISIBLE);

        result.setVisibility(View.INVISIBLE);
        lang2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LanguageActivity.class);
                intent.putExtra("language", "To");
                startActivityForResult(intent, 3);


            }
        });
        cancel.setVisibility(View.INVISIBLE);
        inputText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                cancel.setVisibility(View.VISIBLE);
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        inputText.getText().clear();
                    }
                });
                if (inputText.getText().toString().length() == 0) {
                    cancel.setVisibility(View.GONE);
                    camera.setVisibility(View.VISIBLE);
                    mic.setVisibility(View.VISIBLE);
                } else {
                    camera.setVisibility(View.GONE);
                    mic.setVisibility(View.GONE);
                    result.setVisibility(View.VISIBLE);
                    cancel.setVisibility(View.VISIBLE);

                }

            }
        });
        swap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String swapInput = inputText.getText().toString();
                String swapResult = outputText.getText().toString();
                outputText.setText(swapInput);

                inputText.setText(swapResult);

                String lang1Text = lang1.getText().toString();
                String lang2Text = lang2.getText().toString();
                lang1.setText(lang2Text);
                lang2.setText(lang1Text);


            }
        });
        outputText.setVisibility(View.INVISIBLE);
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                outputHeading.setText(tranLang);
                bar.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                inputword = inputText.getText().toString();
                getTranslation(inputword, lang1code, lang2code);
                outputText.setVisibility(View.VISIBLE);



            }
        });
        mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displaySpeechRecognizer();
            }

        });

        getHistoryValues();

    }

    private void displaySpeechRecognizer() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        // This starts the activity and populates the intent with the speech text.
        startActivityForResult(intent, SPEECH_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            if (requestCode == 2) {
                Inputlang = data.getStringExtra("country");
                lang1code = data.getStringExtra("code");
                lang1.setText(Inputlang);

            } else if (requestCode == 3) {
                tranLang = data.getStringExtra("country");
                lang2code = data.getStringExtra("code");
                lang2.setText(tranLang);
                if (inputText.getText().toString().length() != 0){
                layout.setVisibility(View.VISIBLE);
                outputText.setVisibility(View.VISIBLE);
                    outputHeading.setText(tranLang);
                inputword = inputText.getText().toString();
                getTranslation(inputword,lang1code, lang2code);}

            } else if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
                List<String> results = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                spokenText = results.get(0);
                inputText.setText(spokenText);
                inputword = inputText.getText().toString();
                getTranslation(inputword, lang1code, lang2code);
                outputText.setVisibility(View.VISIBLE);
//                outputText.setText(spokenText);
            }

        }
    }

    private void initiaizePreference() {
        pref = getSharedPreferences("language_pref", MODE_PRIVATE);
        editor = pref.edit();
    }

    private void editLanguages() {
        editor.putString("lan1", "French");
        editor.putString("lan2", "English");
        editor.apply();
    }


    private void getShared() {

        lang1.setText(pref.getString("lan1", ""));
        lang2.setText(pref.getString("lan2", ""));


    }

    private void database() {
        DatabaseModel traslatordao = new DatabaseModel();
        traslatordao.setInputWords(inputword);
        traslatordao.setInputLanguageName(Inputlang);
        traslatordao.setInputLanguageCode(lang1code);
        traslatordao.setOutputWords(resulttext);
        traslatordao.setTranslatedLanguageCode(lang2code);
        traslatordao.setTranslatedLanguageName(tranLang);
        traslatordao.setInputVoice(spokenText);

        TdDatabase = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "database-name").allowMainThreadQueries().build();
        TdDatabase.translatorDao().insertAll(traslatordao);
        Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();

    }

    private void getTranslation(String inputword, String inputLanguage, String targetcode) {
        RetrofitClient retrofitClient = new RetrofitClient();
        Call<JsonArray> translation = retrofitClient.getTranslateInterface().getTrans(inputLanguage, targetcode, inputword);
        StringBuilder Sb = new StringBuilder();
        translation.enqueue(new Callback<JsonArray>() {
            @Override
            public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                bar.setVisibility(View.GONE);
                try {
                    JsonArray langArray = response.body();
                    JsonArray array2 = (JsonArray) langArray.get(0);
                    StringBuilder TransOutputword = new StringBuilder();
                    for (int i = 0; i <= array2.size() - 1; i++) {
                        JsonArray parseresult = (JsonArray) array2.get(i);
                        resulttext = (String) parseresult.get(0).getAsString();
                        if (!resulttext.contains("null")) {
                            TransOutputword.append(resulttext);
                        }
                    }
                    outputText.setText(TransOutputword);
                    database();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<JsonArray> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void getHistoryValues() {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String Inputlang = bundle.getString("InputLanguage");
            String Outputlang = bundle.getString("OutputLanguage");
            String InputText1 = bundle.getString("InputText");
            String OutputText1 = bundle.getString("OutputText");
            lang1.setText(Inputlang);
            lang2.setText(Outputlang);
            inputText.setText(InputText1);
            layout.setVisibility(View.VISIBLE);
            outputText.setVisibility(View.VISIBLE);
            outputText.setText(OutputText1);


        }
    }

}







