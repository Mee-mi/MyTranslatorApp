package api.application.maryam.translater;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TextAdapter extends RecyclerView.Adapter {
    private Context mContext;
    ArrayList<Text> testList= new ArrayList<>();;


    public static class Text1ViewHolder extends RecyclerView.ViewHolder {

        TextView leftText, leftTransText;

        public Text1ViewHolder(View itemView) {
            super(itemView);
            leftText = itemView.findViewById(R.id.leftText);
            leftTransText = itemView.findViewById(R.id.leftText2);
        }

    }

    public static class Text2ViewHolder extends RecyclerView.ViewHolder {

        TextView rightText, rightTransText;

        public Text2ViewHolder(View itemView) {
            super(itemView);
            rightText = itemView.findViewById(R.id.rightText);
            rightTransText=itemView.findViewById(R.id.rightText2);
        }

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case Text.USER_TYPE1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.left_layout, parent, false);
                return new Text1ViewHolder(view);
            case Text.USER_TYPE2:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.right_layout, parent, false);
                return new Text2ViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Text object= testList.get(position);
        if(object!= null){
            switch (object.Type){
                case Text.USER_TYPE2:
                    ((Text2ViewHolder) holder).rightText.setText(object.getUserText1());
                    ((Text2ViewHolder) holder).rightTransText.setText(object.getUserText2());
                    break;
                case Text.USER_TYPE1:
                    ((Text1ViewHolder) holder).leftText.setText(object.getUserText1());
                    ((Text1ViewHolder) holder).leftTransText.setText(object.getUserText2());
                    break;


            }
        }

    }

    @Override
    public int getItemViewType(int position) {

        switch (testList.get(position).Type) {
            case 0:
                return Text.USER_TYPE1;
            case 1:
                return Text.USER_TYPE2;
            default:
                return -1;
        }
    }
    public void setData(ArrayList<Text> list) {
        this.testList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return testList.size();
    }



    }

