package api.application.maryam.translater;

public class LanguageModel {
    String langCode, langName, langNative, langCountryCode;

    public LanguageModel(String langCode, String langName, String langNative, String langCountryCode) {
        this.langCode = langCode;
        this.langName = langName;
        this.langNative = langNative;
        this.langCountryCode = langCountryCode;
    }

    public LanguageModel() {
    }

    public String getLangCode() {
        return langCode;
    }

    public void setLangCode(String langCode) {
        this.langCode = langCode;
    }

    public String getLangName() {
        return langName;
    }

    public void setLangName(String langName) {
        this.langName = langName;
    }

    public String getLangNative() {
        return langNative;
    }

    public void setLangNative(String langNative) {
        this.langNative = langNative;
    }

    public String getLangCountryCode() {
        return langCountryCode;
    }

    public void setLangCountryCode(String langCountryCode) {
        this.langCountryCode = langCountryCode;
    }
}
