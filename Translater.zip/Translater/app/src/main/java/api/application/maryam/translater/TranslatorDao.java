package api.application.maryam.translater;

import android.view.translation.Translator;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TranslatorDao {

    @Insert
    void insertAll(DatabaseModel model);

    @Query("SELECT * FROM DatabaseModel")
    List<DatabaseModel> getdata();
}
