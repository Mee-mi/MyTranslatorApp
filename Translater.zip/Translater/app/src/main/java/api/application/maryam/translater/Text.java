package api.application.maryam.translater;

public class Text {
    public static final int USER_TYPE1=0;
    public static final int USER_TYPE2=1;

    public int Type;
   String UserText1;
   String UserText2 ;

    public Text(int type, String userText1, String userText2) {
        Type = type;
        UserText1 = userText1;
        UserText2 = userText2;
    }

    public int getType() {
        return Type;
    }

    public void setType(int type) {
        Type = type;
    }

    public String getUserText1() {
        return UserText1;
    }

    public void setUserText1(String userText1) {
        UserText1 = userText1;
    }

    public String getUserText2() {
        return UserText2;
    }

    public void setUserText2(String userText2) {
        UserText2 = userText2;
    }
}
