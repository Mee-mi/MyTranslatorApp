package api.application.maryam.translater;

import static android.content.ContentValues.TAG;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ConversActivity extends AppCompatActivity {

    private static final int SPEECH_REQUEST_CODE = 0;
    private static final int SPEECH_REQUEST_CODE2 = 1;
    RecyclerView recview;
    Toolbar toolbar;
    ImageButton Mic1, Mic2;
    TextView lang1, lang2, clear;
     ArrayList<Text> listtext = new ArrayList<>();
     TextAdapter adapter = new TextAdapter();
    String speech = null;
    SharedPreferences sharedPreference;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convers);
        initSHaredPref();
        recview = findViewById(R.id.recyclerViewCon);
        toolbar = findViewById(R.id.Contoolbar);
        lang1 = findViewById(R.id.langMic);
        lang2 = findViewById(R.id.langMic2);
        clear=findViewById(R.id.clear);


        Mic1 = findViewById(R.id.ConimageButton);
        Mic2 = findViewById(R.id.imageButton3);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        lang1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConversActivity.this, LanguageActivity.class);
                intent.putExtra("language", "From");
                startActivityForResult(intent, 2);

            }
        });
        lang1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConversActivity.this, LanguageActivity.class);
                intent.putExtra("language", "FROM");
                startActivityForResult(intent, 2);
            }
        });
        lang2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConversActivity.this, LanguageActivity.class);
                intent.putExtra("language", "To");
                startActivityForResult(intent, 3);

            }
        });
        lang2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConversActivity.this, LanguageActivity.class);
                intent.putExtra("language", "FROM");
                startActivityForResult(intent, 3);
            }
        });

        Mic1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                speech= "leftSpeech";
                displaySpeechRecognizer();

            }
        });
        Mic2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                speech= "rightSpeech";
                displaySpeechRecognizer();

            }
        });
        initializeRecyclerView();
        getSharedPre();

    }

    private void initializeRecyclerView() {
        recview = findViewById(R.id.recyclerViewCon);
        recview.setLayoutManager(new LinearLayoutManager(this));
        recview.setAdapter(adapter);
    }

    private void getSharedPre() {
        String leftName = sharedPreference.getString("LANG1", "English");
        String rightName = sharedPreference.getString("LANG2", "Urdu");
        lang1.setText(leftName);
        lang2.setText(rightName);

    }

    private void initSHaredPref() {
        sharedPreference = getSharedPreferences("my_Pref", MODE_PRIVATE);
        editor = sharedPreference.edit();

    }


    private void displaySpeechRecognizer() {
        Log.d(TAG, "displaySpeechRecognizer: ");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
// This starts the activity and populates the intent with the speech text.
        if (speech.equals("leftSpeech"))
            startActivityForResult(intent, SPEECH_REQUEST_CODE);
        else if (speech.equals("rightSpeech"))
            startActivityForResult(intent, SPEECH_REQUEST_CODE2);

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            if (requestCode == 2) {
                String lang = data.getStringExtra("country");
                editor.putString("LANG1", lang);
                editor.apply();
                lang1.setText(lang);

            } else if (requestCode == 3) {
                String langnew = data.getStringExtra("country");
                editor.putString("LANG2", langnew);
                editor.apply();
                lang2.setText(langnew);

            } else if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
                List<String> results = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                String spokenText = results.get(0);
                listtext.add(new Text(0,spokenText,spokenText));
                adapter.setData(listtext);
                // Do something with spokenText.
            } else if (requestCode == SPEECH_REQUEST_CODE2 && resultCode == RESULT_OK) {
                List<String> results = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                String spokenText = results.get(0);
                listtext.add(new Text(1,spokenText,spokenText));
                adapter.setData(listtext);


            }
        }
    }
}