package api.application.maryam.translater;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.viewHolder> {
    ArrayList<LanguageModel> dataHolder= new ArrayList<>();
    private Context context;
    private int resultCode;


    public LanguageAdapter(Context context, int resultCode) {
        this.context = context;
        this.resultCode = resultCode;
    }

    public void filterList(ArrayList<LanguageModel> filterlist) {
        // below line is to add our filtered
        // list in our course array list.
        dataHolder = filterlist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row, parent, false);
        return new LanguageAdapter.viewHolder(view1);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        holder.langName.setText(dataHolder.get(position).getLangName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent();
                intent.putExtra("country", dataHolder.get(position).langName);
                intent.putExtra("code",dataHolder.get(position).langCode);
                if(resultCode==2)
                ((LanguageActivity)context).setResult(2, intent);
                else
                    ((LanguageActivity)context).setResult(3, intent);
                ((LanguageActivity)context).finish();

//                Intent intent = new Intent(holder.itemView.getContext(), MainActivity.class);
//                intent.putExtra("lang1", dataHolder.get(position).langName);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                holder.itemView.getContext().startActivity(intent);



            }
        });

    }

    @Override
    public int getItemCount() {
        return dataHolder.size();
    }
    public void setData(ArrayList<LanguageModel> list) {
        this.dataHolder = list;
        notifyDataSetChanged();
    }

   public static class viewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView langName;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.imageView);
            langName = itemView.findViewById(R.id.name);

        }

    }

}
