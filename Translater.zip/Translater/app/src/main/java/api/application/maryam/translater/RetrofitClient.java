package api.application.maryam.translater;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    public static String TRANSALTE_BASE_URL = "https://translate.googleapis.com/";


    public TranslatorInterface getTranslateInterface() {
        retrofit2.Retrofit retrofit = new retrofit2.Retrofit.Builder()
                .baseUrl(TRANSALTE_BASE_URL)
                .client(makeOkHTTPClient())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(TranslatorInterface.class);

    }

    private OkHttpClient makeOkHTTPClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS).build();


    }
}
