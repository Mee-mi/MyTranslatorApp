package api.application.maryam.translater;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.viewholder> {
    List<DatabaseModel> modelList;
    Context context;

    public HistoryAdapter(List<DatabaseModel> modelList, Context context) {
        this.modelList = modelList;
        this.context = context;
    }

    public void setDatabaseModel(List<DatabaseModel> modelList) {
        this.modelList = modelList;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view1= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new viewholder(view1);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        holder.inputText.setText(modelList.get(position).getInputWords());
        holder.outputText.setText(modelList.get(position).getOutputWords());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("InputLanguage",modelList.get(position).getInputLanguageName());
                bundle.putString("OutputLanguage",modelList.get(position).getTranslatedLanguageName());
                bundle.putString("InputText",modelList.get(position).getInputWords());
                bundle.putString("OutputText",modelList.get(position).getOutputWords());
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    class viewholder extends RecyclerView.ViewHolder {
        TextView inputText, outputText;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            inputText=itemView.findViewById(R.id.Inputname);
            outputText=itemView.findViewById(R.id.Outputname);
        }
    }
}
