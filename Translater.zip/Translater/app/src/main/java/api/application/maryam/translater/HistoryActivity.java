package api.application.maryam.translater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    Toolbar toolbar;
    RecyclerView recyclerView;
    AppDatabase database;
    List<DatabaseModel> modelList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        toolbar=findViewById(R.id.Histoolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//for home
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        recyclerView=findViewById(R.id.historyRec);
        database = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "database-name").allowMainThreadQueries().build();
        List<DatabaseModel> dataList= database.translatorDao().getdata();
        recyclerView.setLayoutManager(new LinearLayoutManager(HistoryActivity.this));
        HistoryAdapter adapter= new HistoryAdapter(modelList,this);
        recyclerView.setAdapter(adapter);
        adapter.setDatabaseModel(dataList);
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));
    }
}