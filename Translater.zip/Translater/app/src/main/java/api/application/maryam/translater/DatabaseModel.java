package api.application.maryam.translater;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class DatabaseModel {
    @PrimaryKey(autoGenerate = true)
    public int Tid;

    @ColumnInfo(name = "input_words")
    public String InputWords;

    @ColumnInfo(name = "Output_words")
    public String OutputWords;

    @ColumnInfo(name = "Input_LanguageName")
    public String InputLanguageName;

    @ColumnInfo(name = "Input_LanguageCode")
    public String InputLanguageCode;

    @ColumnInfo(name = "Translated_LanguageName")
    public String TranslatedLanguageName;

    @ColumnInfo(name = "Translated_LanguageCode")
    public String TranslatedLanguageCode;

    @ColumnInfo(name = "is_Favorite")
    public Boolean isFavorite;

    @ColumnInfo(name = "Input_voice")
    public String InputVoice;

    public String getInputVoice() {
        return InputVoice;
    }

    public void setInputVoice(String inputVoice) {
        InputVoice = inputVoice;
    }

    public Boolean getFavorite() {
        return isFavorite;
    }

    public void setFavorite(Boolean favorite) {
        isFavorite = favorite;
    }

    public int getTid() {
        return Tid;
    }

    public void setTid(int tid) {
        Tid = tid;
    }

    public String getInputWords() {
        return InputWords;
    }

    public void setInputWords(String inputWords) {
        InputWords = inputWords;
    }

    public String getOutputWords() {
        return OutputWords;
    }

    public void setOutputWords(String outputWords) {
        OutputWords = outputWords;
    }

    public String getInputLanguageName() {
        return InputLanguageName;
    }

    public void setInputLanguageName(String inputLanguageName) {
        InputLanguageName = inputLanguageName;
    }

    public String getInputLanguageCode() {
        return InputLanguageCode;
    }

    public void setInputLanguageCode(String inputLanguageCode) {
        InputLanguageCode = inputLanguageCode;
    }

    public String getTranslatedLanguageName() {
        return TranslatedLanguageName;
    }

    public void setTranslatedLanguageName(String translatedLanguageName) {
        TranslatedLanguageName = translatedLanguageName;
    }

    public String getTranslatedLanguageCode() {
        return TranslatedLanguageCode;
    }

    public void setTranslatedLanguageCode(String translatedLanguageCode) {
        TranslatedLanguageCode = translatedLanguageCode;
    }


}

